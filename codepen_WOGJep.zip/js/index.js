	/* Parallax code usage: bindScrollRate($('#parallaxContainer'));
		where #parallaxContainer is a div with a child element with the class .parallax-backgroud that has a background image
		larger than the container div passed in.  The is code moves the background image in a parallax fashion.
	*/
jQuery(document).ready(function($){
  
  // turn this to false to disable console output
  var debugToggle = true;
	if (debugToggle) console.log("Start");
  
  var windowHeight = 0, windowWidth = 0, windowResizeId;
  
  /*  The function bindScroll is used to enable parallax functionality on the
   *  parallaxContainer, which contains a div with a "parallax-background" class.
   *  
   *  To use, pass in as a jQuery object the parallaxBackground div
   *  for example: bindScroll( $('#parallaxContainer') );
   */
	var bindScroll = function(outerContainer) {
		
		var parallaxBackground = outerContainer.find('.parallax-background');
		var image_url = parallaxBackground.css('background-image'), image;

    /* We need to get the height of the image. This code does that by creating an img 
     * witht the same url as the parallax background image.
     * The img is only in memory, never written to the DOM.
     */
    
		// Remove url() or in case of Chrome url("")
		if(typeof image_url !== 'undefined'){
			image_url = image_url.match(/^url\("?(.+?)"?\)$/); // find the url string, with the "url()" bit
		
			if (image_url[1]) {
				image_url = image_url[1];
				image = new Image(); // make the image in memory so we can get the dimensions
	
				// Declare the on load function to run when the image has been loaded in memory
				$(image).on('load', function () {
					//now we know the image width and height
					
					if (debugToggle)console.log("Background image: " + image.width + 'x' + image.height);
					
          /* because we know the width and height within this scope, 
           * setSizes knows the correct dimensions.  We will also call
           * this function on window resize
           */
					function setSizes(){
						parallaxBackground = outerContainer.find('.parallax-background');
						windowHeight = $(window).height();
						windowWidth = $(window).width();
						var parentHeight = parallaxBackground.parent().parent().height();
            
            // Write some css styles inline to control behavior of the parallax elements:
						parallaxBackground.parent().css('display', parallaxBackground.css('display')); 
						parallaxBackground.css({'background-size': 'auto ' + image.height, 'height': image.height}); /* set the background's height, let the width size to keep the proportions */
						parallaxBackground.parent().css({'height': parentHeight + 'px', 'overflow-y': 'hidden'}); /* set the parent height, which cannot be larger than the background hieght or it will look gross */
					}
          
          // now run that setSizes function 
					setSizes();

          /* Now that we've done all the groundwork, we can actually change the 
           * position of the image on scroll. So, set up a function to call when
           * the user scrolls
           */
					$(window).on('scroll', function(e){
						improvedHandleParallaxScroll(outerContainer, image.height);
					});
          
          // And finally, set the setSizes function to run when the window resizes 
					$(window).resize(setSizes);
				});
	
        /* Now set the image url.  When it's loaded, it will trigger the on load 
         * function which actully does the parallax movement
         */
				image.src = image_url;  
			}
		}	
	}
	
	
	/* improvedHandleParallaxScroll function actually moves the parallax background 
   * image.  It takes as parameters, the parallaxContiner which was passed in to 
   * bindScroll, and the height of the image, which was determined above
   * by creating an image in memory using the url of the background image.
   * This function will be called when the image in memory has loaded, and when
   * the sizes have been set by setSizes.  
   * 
   */
	var improvedHandleParallaxScroll = function (parallaxContainer, imageHeight) {
		var parallaxBackground = parallaxContainer.find('.parallax-background');
		var containerHeight = parallaxContainer.height(); // outer height
    
		var scroll = $(document).scrollTop() - parallaxContainer.offset().top + windowHeight; // when the bottom of the viewport hits the top of the background, this will be 0
    
		// scrollAmount is the amount we want to move the parallax background image.  We use max and min to keep it from ever going out of bounds, which can be visible when scrolling quickly.
		var scrollAmount = 
        Math.min(
          Math.max(
            /* here's the magic math */
            -1 * scroll * (imageHeight - containerHeight) / (containerHeight + windowHeight),
			      -1 * (imageHeight - containerHeight) 
					),
        0);
    
		if (debugToggle) console.log("Scroll Amount: " + scrollAmount);
		
    /* and actually write it out. */
		parallaxBackground.css({'transform': 'translate3d(0px,' + scrollAmount + 'px, 0px)'}); // 3d transform to use gpu hardware accel, if available
	}	
	
	
	// Parallax functions for parallaxContainer block
	bindScroll($('#parallaxContainer'));
});